English:
it's recommended to place the .exe file in a separate folder after successful extraction
Files shared on websites will be stored in the shared_files folder until they are manually deleted.

简体中文:
当成功解压后，推荐的做法是将exe文件放置在单独的文件夹内。
网页上共享的文件会被保存在shared_files文件夹内，直到被手动删除。

